/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("loadindex", 
		"URL=https://dev.bluealgo.com/smartformup/loadindex?opportunityId=0060o00001eSIJ0AAO&customerid=cust1005&accesstoken=uXCxZRKU-Mf2wiTg3_A8dPu957taLXxP", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("ESign_Submit");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	lr_think_time(14);

	web_submit_data("genericForm", 
		"Action=https://dev.bluealgo.com/smartformup/genericForm", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://dev.bluealgo.com/smartformup/loadindex?opportunityId=0060o00001eSIJ0AAO&customerid=cust1005&accesstoken=uXCxZRKU-Mf2wiTg3_A8dPu957taLXxP", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=field_06kl9fm", "Value=D Manikandan", ENDITEM, 
		"Name=field_1kogmq4", "Value=RB31", ENDITEM, 
		"Name=field_0znfled", "Value=1004", ENDITEM, 
		"Name=field_0ptq5xw", "Value=", ENDITEM, 
		"Name=applicant_type_idt", "Value=Individual", ENDITEM, 
		"Name=applicant-photo-picker1", "Value=", "File=Yes", ENDITEM, 
		"Name=panCardFile1", "Value=", "File=Yes", ENDITEM, 
		"Name=A1_Document_List1", "Value=Aadhaar Front", ENDITEM, 
		"Name=apptnc_aggre_41", "Value=on", ENDITEM, 
		"Name=A1_Individual_Party_Salutation_1", "Value=Mr.", ENDITEM, 
		"Name=A1_Individual_Party_firstname_1", "Value=D", ENDITEM, 
		"Name=A1_Individual_Party_lastname_1", "Value=Manikandan", ENDITEM, 
		"Name=A1_Individual_Mobile_1", "Value=9390174341", ENDITEM, 
		"Name=A1_Individual_AdditionalMobile", "Value=", ENDITEM, 
		"Name=A1_Individual_Landline", "Value=", ENDITEM, 
		"Name=A1_Individual_Email_1", "Value=mudapaka.vamsi@larsentoubro.com", ENDITEM, 
		"Name=A1_Individual_Additional_Email_1", "Value=", ENDITEM, 
		"Name=A1_Individual_PAN_No_1", "Value=BNZPM2501F", ENDITEM, 
		"Name=A1_Individual_AADHAR", "Value=841615903267", ENDITEM, 
		"Name=A1_Individual_DOB_No_1", "Value=1986-07-16", ENDITEM, 
		"Name=A1_House_Number__c", "Value=1-111", ENDITEM, 
		"Name=A1_Building_Name__c", "Value=Gram", ENDITEM, 
		"Name=A1_Permanent_Locality__c", "Value=Sagar Madhya Pradesh", ENDITEM, 
		"Name=A1_BillingStreet", "Value=Gunjoura Gunjoura", ENDITEM, 
		"Name=A1_BillingCity", "Value=Gunjora", ENDITEM, 
		"Name=A1_BillingPostalCode", "Value=470242", ENDITEM, 
		"Name=A1_BillingState", "Value=MadhyaPradesh", ENDITEM, 
		"Name=A1_BillingCountry", "Value=India", ENDITEM, 
		"Name=A1_Same_as_permanent_address", "Value=on", ENDITEM, 
		"Name=A1_Shipping_House_Number__c", "Value=", ENDITEM, 
		"Name=A1_Shipping_Building_Name__c", "Value=", ENDITEM, 
		"Name=A1_Permanent_Locality__c", "Value=Sagar Madhya Pradesh", ENDITEM, 
		"Name=A1_ShippingStreet", "Value=", ENDITEM, 
		"Name=A1_ShippingCity", "Value=", ENDITEM, 
		"Name=A1_ShippingPostalCode", "Value=", ENDITEM, 
		"Name=A1_ShippingState", "Value=", ENDITEM, 
		"Name=A1_ShippingCountry", "Value=", ENDITEM, 
		"Name=A1_Individual_Nationality_1", "Value=Resident Indian", ENDITEM, 
		"Name=ApplicantType1", "Value=Individual", ENDITEM, 
		"Name=A1_RelationShip", "Value=DonotInclude", ENDITEM, 
		"Name=A1_Passport", "Value=", ENDITEM, 
		"Name=apptnc_aggre_21", "Value=on", ENDITEM, 
		"Name=page3_last_custom_id", "Value=on", ENDITEM, 
		"Name=field_0zeledr", "Value=3BHK Superia", ENDITEM, 
		"Name=field_16j683l", "Value=RB31", ENDITEM, 
		"Name=field_17deei2", "Value=1004", ENDITEM, 
		"Name=field_1b4e0hj", "Value=934", ENDITEM, 
		"Name=field_1z08kmk", "Value=0", ENDITEM, 
		"Name=field_0ylwllp", "Value=1 SINGLE", ENDITEM, 
		"Name=field_0qesuep", "Value=010", ENDITEM, 
		"Name=field_1hlrs6t", "Value=1,43,98,370", ENDITEM, 
		"Name=field_0qesuep", "Value=One Crore Forty Three Lakhs Ninety Eight Thousands Three Hundred Seventy", ENDITEM, 
		"Name=field_0qesueppp", "Value=Raintree Boulevard", ENDITEM, 
		"Name=field_0qesueppparea", "Value=934.00", ENDITEM, 
		"Name=apptnc_aggre_4", "Value=on", ENDITEM, 
		"Name=field_0bcwptd", "Value=Hoarding", ENDITEM, 
		"Name=apptnc_aggre_5", "Value=on", ENDITEM, 
		"Name=payment_edit_1", "Value=on", ENDITEM, 
		"Name=payment_source_1", "Value=Cheque", ENDITEM, 
		"Name=payment_source_image", "Value=", "File=Yes", ENDITEM, 
		"Name=field_0762z3t", "Value=5020000", ENDITEM, 
		"Name=field_0jf5m29", "Value=Five Lakh Fifty Five Thousand ", ENDITEM, 
		"Name=field_1k6w4bg", "Value=", ENDITEM, 
		"Name=field_0ag0ocl", "Value=LTRDL -Olivia at Raintree Boulevard -CL7", ENDITEM, 
		"Name=field_0ag0ocl", "Value=2024-02-15", ENDITEM, 
		"Name=payment_source_1", "Value=Cheque", ENDITEM, 
		"Name=apptnc_aggre_6", "Value=on", ENDITEM, 
		"Name=A1_Individual_DOB_1", "Value=1986-07-16", ENDITEM, 
		"Name=A1_Individual_Mother_Tounge_1", "Value=Punjabi", ENDITEM, 
		"Name=A1_Individual_Home_Town", "Value=", ENDITEM, 
		"Name=A1_Individual_Name_of_Customer_Company", "Value=L&T", ENDITEM, 
		"Name=A1_Individual_Designation_1", "Value=Solution Consultant", ENDITEM, 
		"Name=A1_Individual_Office_Location_1", "Value=Powai", ENDITEM, 
		"Name=A1_Individual_Industry_1", "Value=Construction", ENDITEM, 
		"Name=apptnc_aggre_7", "Value=on", ENDITEM, 
		"Name=field_1judges", "Value=D Manikandan", ENDITEM, 
		"Name=field_18ry4zv", "Value=1-111 Gram Sagar Madhya Pradesh Gunjoura Gunjoura Gunjora 470242 MadhyaPradesh India", ENDITEM, 
		"Name=apptnc_aggre_9", "Value=on", ENDITEM, 
		"Name=apptnc_aggre_10", "Value=on", ENDITEM, 
		"Name=opportunitypass", "Value=0060o00001eSIJ0AAO", ENDITEM, 
		"Name=projectid", "Value=cust1005", ENDITEM, 
		"Name=esignstaus", "Value=true", ENDITEM, 
		"Name=applicantCount", "Value=1", ENDITEM, 
		"Name=generatedformPDF", "Value=", ENDITEM, 
		"Name=pdfContent", "Value={\"applicants\":[{\"type\":\"Primary Applicant\",\"imageSrc\":\"20240215052929811885.jpg\",\"panNumber\":\"BNZPM2501F\",\"panValidated\":\"check\",\"aadharNumber\":\"841615903267\",\"name\":\"D Manikandan\",\"phone\":\"9390174341\",\"email\":\"mudapaka.vamsi@larsentoubro.com\",\"permAdd\":\"1-111, Gram, Sagar Madhya Pradesh, Gunjoura Gunjoura, Gunjora, 470242, MadhyaPradesh, India\",\"corspAdd\":\"1-111, Gram, Sagar Madhya Pradesh, Gunjoura Gunjoura, Gunjora, 470242, "
		"MadhyaPradesh, India\",\"passport\":\"\",\"relWithPrimaryApplicant\":\"DonotInclude\"}],\"applicantsKyc\":[{\"appType\":\"Primary Applicant\",\"docs\":[{\"type\":\"1. PAN Card\",\"src\":\"20240215052935610266.jpg\",\"subtype\":\"PAN Card\"}]}],\"paymentSources\":[{\"Amount in Words\":\"Five Lakh Fifty Five Thousand \",\"IFSC\":\"-\",\"MICR\":\"\",\"Payee Name\":\"\",\"Amount in Figures\":\"5020000\",\"Signature Present\":\"-\",\"Branch Name\":\"-\",\"Cheque No\":\"\",\"Account No\":\"35583810025\""
		",\"Bank Name\":\"-\",\"Date\":\"\",\"imageSrc\":\"20240215053017000932.jpg\",\"rowId\":1,\"Amount__c\":\"5020000\",\"Bank_Name__c\":\"\",\"Mode_Of_Payment__c\":\"Cheque\",\"Date_of_payment__c\":\"2024-02-15\"}],\"isConcent\":false,\"unitNo\":\"1004\",\"projectLogo\":\"\",\"consentFormType\":\"RB31\",\"firstPage\":{\"first_pname\":\"D Manikandan\",\"first_tname\":\"Raintree Boulevard, RB31, 1004\"},\"bookingSrc\":{\"io_source\":\"Hoarding\"},\"unitDetails\":{\"project_name\":\"Raintree Boulevard\","
		"\"tower\":\"RB31\",\"apartment_no\":\"1004\",\"carpet_area\":\"934\",\"type_of_apartment\":\"3BHK Superia\",\"floor_no\":\"010\",\"parking_requested\":\"1 SINGLE\",\"ancillary_area\":\"0\",\"total_area\":\"934.00\",\"flat_cost\":\"1,43,98,370\",\"agval_words\":\"One Crore Forty Three Lakhs Ninety Eight Thousands Three Hundred Seventy\"},\"about\":{\"date_of_birth\":\"16-07-1986\",\"mother_tongue\":\"Punjabi\",\"marital_status\":\"NA\",\"occuptions\":\"NA\",\"name_of_firm\":\"L&T\",\"my_desination"
		"\":\"Solution Consultant\",\"office_address\":\"Powai\",\"ind_type\":\"Construction\"},\"baDetails\":{},\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\"}", ENDITEM, 
		"Name=A1_Individual_Signature_Process", "Value=Now", ENDITEM, 
		LAST);

	lr_end_transaction("ESign_Submit",LR_AUTO);

	lr_start_transaction("Esign");

	web_add_cookie("__RequestVerificationToken=6Tt8fDDTyLf-zj1WdTikHYQvggA8CyF-bD0xNjtW0CBGjtaSkBNQQZyIxlP-IS47CbkObHuxGtIBSsb-8lyw-RFXe1e2GLU7pcnqzB746Ck1; DOMAIN=emgateway.emsigner.com");

	lr_think_time(22);

	web_submit_form("Index", 
		"Action=https://emgateway.emsigner.com/eMsecure/V3_0/Index", 
		"Snapshot=t43.inf", 
		ITEMDATA, 
		EXTRARES, 
		"Url=/Assets/fonts/Gilroy-Regular.woff2", "Referer=https://emgateway.emsigner.com/Assets/css/gateway-style.css?20240115110129590", ENDITEM, 
		"Url=/Assets/fonts/font-awesome/fonts/fontawesome-webfont.woff?v=4.2.0", "Referer=https://emgateway.emsigner.com/Assets/fonts/font-awesome/css/font-awesome.css", ENDITEM, 
		LAST);

	web_submit_data("ImageGeneration", 
		"Action=https://emgateway.emsigner.com/eMsecure/SignerGateway/ImageGeneration", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://emgateway.emsigner.com/eMsecure/V3_0/Index", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=FilePath", "Value=ESGT20240215110129501.pdf", ENDITEM, 
		"Name=__RequestVerificationToken", "Value=f8Zk9VOZuvSdCHSZFIwaYSleR-oi1DIRtzA3TyVkBqVxKqU9QRtCfNA6ZUqhsod3RKGoUAPiP_ZCova17uEVvgc29isX0QOManbidto35441", ENDITEM, 
		LAST);

	web_submit_data("GetCustomCoordinates", 
		"Action=https://emgateway.emsigner.com/eMsecure/V3_0/GetCustomCoordinates", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://emgateway.emsigner.com/eMsecure/V3_0/Index", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SearchText", "Value=", ENDITEM, 
		"Name=Anchor", "Value=", ENDITEM, 
		"Name=FileName", "Value=ESGT20240215110129501.pdf", ENDITEM, 
		"Name=InitialsSearchText", "Value=", ENDITEM, 
		"Name=InitialsAnchor", "Value=", ENDITEM, 
		"Name=__RequestVerificationToken", "Value=f8Zk9VOZuvSdCHSZFIwaYSleR-oi1DIRtzA3TyVkBqVxKqU9QRtCfNA6ZUqhsod3RKGoUAPiP_ZCova17uEVvgc29isX0QOManbidto35441", ENDITEM, 
		LAST);

	lr_end_transaction("Esign",LR_AUTO);

	return 0;
}